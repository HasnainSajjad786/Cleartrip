from unittest import TestLoader, TestSuite, TextTestRunner
from Scripts.Test_Book_Flight import Test_Book_Flight

class TestRunner:
    def execute(self):

        loader = TestLoader()
        suite = TestSuite((
            loader.loadTestsFromTestCase(Test_Book_Flight),
            # loader.loadTestsFromTestCase(newcase)
        ))
        runner = TextTestRunner(verbosity=3)
        runner.run(suite)

run_test = TestRunner()
run_test.execute()
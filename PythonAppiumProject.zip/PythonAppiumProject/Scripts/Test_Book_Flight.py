import unittest

from selenium import webdriver
from PageObjects.Pages.SearchFlightPage import SearchFlightPage
import time

class Test_Book_Flight(unittest.TestCase):

    def setUp(self):
        print("Here")

        self.driver = webdriver.Chrome(executable_path=r"C:\\Users\\223033037\\Downloads\\chromedriver_win32\\chromedriver.exe")


    def tearDown(self):
        #To do the cleanup after test has executed.
        self.driver.close()
        self.driver.quit()
        print("Done")

    def test_search_flight_page_load(self):
        self.searchPage = SearchFlightPage(self.driver)
        self.searchPage.select_trip_way("RADIO_ROUNDTRIP")
        self.searchPage.fill_from_field("Mumbai")
        time.sleep(3)
        self.searchPage.fill_to_field("Delhi")
        self.searchPage.fill_from_date_picker('Sat, Aug 14')
        time.sleep(10)

    # def test_search_flight(self):
    #     self.searchPage.select_trip_way("RADIO_ROUNDTRIP")
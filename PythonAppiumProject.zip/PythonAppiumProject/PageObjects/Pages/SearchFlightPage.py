from PageObjects.Pages.Base import Base
from PageObjects.Locators import Locators

import time


class SearchFlightPage(Base):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver.get("https://www.cleartrip.com/flights")
        time.sleep(20)

    def select_trip_way(self, trip_way):
        if trip_way == "RADIO_ROUNDTRIP":
           self.click(Locators.RADIO_ROUNDTRIP)


    def fill_from_field(self, from_details):
        self.enter_text(Locators.FROM_FIELD , from_details)

    def fill_to_field(self, to_details):
        self.enter_text(Locators.TO_FIELD , to_details)


    def fill_from_date_picker(self, from_date):
        self.click(Locators.FROM_DATEPICKER)
        time.sleep(2)
        self.click(Locators.date_picker_from(from_date))


from selenium.webdriver.common.by import By

class Locators():
    #Login Page Locators
    EMAIL = (By.ID,"")
    PASSWORD = (By.ID,"")

    RADIO_ROUNDTRIP = (By.CSS_SELECTOR,".radio:nth-child(2) .radio__circle")

    FROM_FIELD = (By.CSS_SELECTOR,".null")
    TO_FIELD = (By.CSS_SELECTOR,"div:nth-child(5) > div > .p-relative .field")

    FROM_DATEPICKER = (By.CSS_SELECTOR,".to-ellipsis:nth-child(1)")

    def date_picker_from(date):
         FROM_DATEPICKER_TEXT = (By.XPATH, "//button[contains(.,'"+date+"')]")
         return FROM_DATEPICKER_TEXT

